<?php
    include 'functions.php';
    $db = getDB();
    
//    if ($db -> connect_errno) {
//       echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
//       exit();
//   }
    if(!$db){
        die("Could not Connect:".mysqli_connect_error());
    }
    else{
        $name = $_POST["name"];
        $email = $_POST["email"];
        $content = $_POST["content"];
        if(empty($name)||empty($email)||empty($content)){
            echo "Please fill *";
        }
        else{
            $name = mysqli_real_escape_string($db, $name);
            $email = mysqli_real_escape_string($db, $email);
            $content = mysqli_real_escape_string($db, $content);

            $sql="INSERT INTO personal_info(name,email_address,content)VALUES('$name','$email','$content')
                ";
            if(mysqli_query($db,$sql)){
                echo "Thank you, your email has been sent. We will get back to you shortly.";
            }
            else{
                echo "Fail to fill out";
            }
            mysqli_close($db);
        }
        
    }


    
 
    

?>
<!DOCTYPE html>
<html>
    <head>
        <title>contact</title>
        <meta name="robots" content="noindex">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    
    <body>
        <div class="navbar">
            <div class="logo">
                <a href="index.html">
                    <img src="images/bemo-logo2.png" width="167" height="100" alt="Site logo" >
                </a>
            </div>
            <nav class="link">
                <div class="toggle">
                    <a class="icon">
                        <i class="fa fa-bars fa-2x" aria-hidden="true" ></i>
                    </a>
                </div>
                <ul class="menu">
                  <li><a href="index.html">Main</a></li>
                  <li><a href="#">How To Prepare</a></li>
                  <li><a href="#">CDA Interview Questions</a></li>
                  <li><a href="contact-us.php">Contact Us</a></li>
                </ul>
            </nav>
        </div>
    
        <div class="small">
            <nav>
                <ul class="menu2">
                  <li><a href="index.html">Main</a></li>
                  <li><a href="#">How To Prepare</a></li>
                  <li><a href="#">CDA Interview Questions</a></li>
                  <li><a href="contact-us.php">Contact Us</a></li>
                </ul>
            </nav>
        </div>
        
        <img id="featureImg" src="http://cdainterview.com/resources/contact-us.png">

        <section>
            <div id="padding">
                <div class="message-text">
                    <span style="font-size:17px; font-weight:bold; ">BeMo Academic Consulting Inc. </span>
                    <br>
                    <span>
                        <span style="font-size:13px; font-weight:bold; ">
                            <u>Toll Free</u>
                        </span>
                        <span style="font-size:13px; ">: </span>
                        <span style="font-size:14px; ">1-855-900-BeMo (2366)</span>
                        <span style="font-size:13px; "><br></span>
                        <span style="font-size:13px; font-weight:bold; ">
                            <u>Email</u>
                        </span>
                        <span style="font-size:13px; ">: </span>
                        <span style="font-size:14px; ">info@bemoacademicconsulting.com</span>
                    </span>
                </div>
                <br>
                <form action="userinfo.php" method="post" id="frmBox" enctype="multipart/form-data">
                    <div>
                        <div class="name-text">
                            <label class="label0"><span class="name-style">Name:</span></label> *<br>
                            <input class="form-input-field" id="txt_name" type="text" value="" name="name" size="40"><br><br>

                            <label>Email Address:</label> *<br>
                            <input class="form-input-field" id="txt_email" type="text" value="" name="email" size="40"><br><br>

                            <label>How can we help you?</label> *<br>
                            <textarea class="form-input-field" id="txt_text" name="content" rows="8" cols="38"></textarea><br><br>

                            <div style="display: none;">
                                <div class="message-text">
                                    <span style="font-size:17px; font-weight:bold; ">BeMo Academic Consulting Inc.
                                    </span><br>
                                    <span>
                                        <span style="font-size:13px; font-weight:bold; ">
                                            <u>Toll Free</u>
                                        </span>
                                        <span style="font-size:13px; ">: </span>
                                        <span style="font-size:14px; ">1-855-900-BeMo (2366)</span>
                                        <span style="font-size:13px; "><br></span>
                                        <span style="font-size:13px; font-weight:bold; ">
                                            <u>Email</u>
                                        </span><span style="font-size:13px; ">: </span>
                                        <span style="font-size:14px; ">info@bemoacademicconsulting.com</span>
                                    </span>
                                </div>
                              <label>Spam Protection: Please don't fill this in:</label>
                              <textarea name="comment" rows="1" cols="1"></textarea>
                            </div>
                            <input type="hidden" name="form_token" value="17618896315eac730e4c19e">
                            <input class="form-input-button" type="reset" name="resetButton" value="Reset">
                            <input class="form-input-button" type="submit" id="submit" name="submitButton" value="Submit">
                            
                        </div>
                        
                        
                  </div>
                </form>

            <br>
            <div class="form-footer">
                <span style="font-size:15px; font-weight:bold; ">
                    <u>Note</u>
                </span>
                <span style="font-size:15px; ">: If you are having difficulties with our contact us form above, send us an email to info@bemoacademicconsulting.com (copy &amp; paste the email address)
                </span>
                <span style="font-size:13px; "><br></span>
                </div>
                <br>
            </div>
            
        </section>
        
        <footer>
        <div class="footer-text">
            <p class="text">©2013-2016 BeMo Academic Consulting Inc. All rights reserved. <a href="http://www.cdainterview.com/disclaimer-privacy-policy.html" target="_blank">Disclaimer &amp; Privacy Policy.</a><a href="mailto:info@bemoacademicconsulting.com" id="rw_email_contact">Contact Us</a>
            </p>
        </div>
        <div class="social-icon">
            
            <a class="fa fa-facebook" href="https://www.facebook.com/bemoacademicconsulting"></a>
            <a class="fa fa-twitter" href="https://twitter.com/BeMo_AC"></a>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('.icon').click(function(){
                //$('.small nav').toggleClass('.active');
                $('.small nav').toggle();
            })
            //$(".icon").click(function(){
            //    $(".small nav").show();
            //})
            
        })
    </script>
    <script>
        $(document).ready(function(){
            $('#submit').click(function(){
                var name = $("#txt_name").val();
                var email = $("#txt_email").val();
                var content = $("#txt_text").val();
                $.ajax({
                    url:'userinfo.php',
                    type:'post',
                    //data:$('#frmBox').serialize(),
                    data:{name:name,email:email,content:content},
                    success:function(result, status, xhr){
                        //$('#success').html(response);
                        
                        //location.reload(); // reloading page
                        $(".message-text").html(result);
                        
                    }
                });
                //var form=document.getElementById('frmBox').reset();
                return false;//this false is so important
            })
        })
        
    </script>
<!--
    <script>
        $(".menu li a").click(function() {          
            $(".menu li a").removeClass("active"); 
            $(this).addClass("active");          
        });    
    </script>
-->
    </body>


</html>
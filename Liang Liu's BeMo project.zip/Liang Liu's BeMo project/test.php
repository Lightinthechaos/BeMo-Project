<html>
    <form action="test.php" method="get">
        <label>Name:</label> *<br>
        <input class="form-input-field" type="text" value="" name="name" size="40"><br><br>
        <input class="form-input-button" type="submit" name="submitButton" value="Submit">
    </form>

    <?php

//    include 'functions.php';
//    $db = getDB();
//
//    if ($db -> connect_errno) {
//       echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
//       exit();
//    }
    echo "Thank you for your Comment!";
    echo $_GET["name"];


    ?>
    </html>